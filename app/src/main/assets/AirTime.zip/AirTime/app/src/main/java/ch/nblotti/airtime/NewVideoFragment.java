package ch.nblotti.airtime;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.SurfaceTexture;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SeekBar;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;

import java.io.IOException;

import ch.nblotti.airtime.databinding.FragmentNewVideoBinding;


public class NewVideoFragment extends Fragment implements TextureView.SurfaceTextureListener {


    public static final String TAG = "FirstFragment";
    public static final int NEXT_STEP = 1;
    public static final int PREVIOUS_STEP = 50;

    private int start_pos = 0;

    private static final int REQUEST_EXTERNAL_STORAGE = 1;
    private static String[] PERMISSIONS_STORAGE = {
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
    };
    private FragmentNewVideoBinding binding;
    private MediaPlayer mediaPlayer;


    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

        binding = FragmentNewVideoBinding.inflate(inflater, container, false);

        return binding.getRoot();

    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);


    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        verifyStoragePermissions(getActivity());
        mediaPlayer = new MediaPlayer();
        binding.textureView.setSurfaceTextureListener(this);

        ContentResolver resolver = getActivity().getApplicationContext()
                .getContentResolver();

        String readOnlyMode = "r";
        binding.previous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final int pos = mediaPlayer.getCurrentPosition() - PREVIOUS_STEP >= 0 ? mediaPlayer.getCurrentPosition() - PREVIOUS_STEP : 0;
                new Thread(new Runnable() {
                    public void run() {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                            mediaPlayer.seekTo(pos, MediaPlayer.SEEK_CLOSEST);
                        else
                            mediaPlayer.seekTo((int) pos);
                    }
                }).start();
            }
        });
        binding.next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final int pos = mediaPlayer.getCurrentPosition() + NEXT_STEP <= mediaPlayer.getDuration() ? mediaPlayer.getCurrentPosition() + NEXT_STEP : mediaPlayer.getDuration();
                new Thread(new Runnable() {
                    public void run() {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                            mediaPlayer.seekTo(pos, MediaPlayer.SEEK_CLOSEST);
                        else
                            mediaPlayer.seekTo((int) pos);


                    }
                }).start();
            }
        });

        binding.start.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {

                NewVideoFragment.this.start_pos = mediaPlayer.getCurrentPosition();
                binding.difference.setText("0");

            }
        });

        binding.end.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {
                Intent intent=new Intent("android.media.action.VIDEO_CAPTURE");
                intent.putExtra("android.intent.extra.durationLimit", 120);
                someActivityResultLauncher.launch(intent);

            }
        });

    }

    ActivityResultLauncher<Intent> someActivityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        // There are no request codes
                        doSomeOperations(result.getData());
                    }
                }

                ;
            });

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onSurfaceTextureAvailable(@NonNull SurfaceTexture surfaceTexture, int i, int i1) {


        Surface surface = new Surface(surfaceTexture);
        mediaPlayer.setSurface(surface);
        // mediaPlayer.prepareAsync();
        mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mediaPlayer) {


                mediaPlayer.setOnSeekCompleteListener(new MediaPlayer.OnSeekCompleteListener() {
                    @Override
                    public void onSeekComplete(MediaPlayer mediaPlayer) {
                        Log.i(TAG, String.format("POSITION : %d", mediaPlayer.getCurrentPosition()));
                        binding.position.setText(String.valueOf(mediaPlayer.getCurrentPosition()));
                        binding.seekBar.setProgress(mediaPlayer.getCurrentPosition());

                        int diff = mediaPlayer.getCurrentPosition() - NewVideoFragment.this.start_pos;
                        String difference = String.valueOf(diff <= 0 ? 0 : diff);
                        binding.difference.setText(difference);

                    }
                });

                binding.seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

                    Boolean tracking = false;

                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean b) {


                        new Thread(new Runnable() {
                            public void run() {
                                if (tracking)
                                    mediaPlayer.seekTo(progress);

                            }
                        }).start();
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {
                        tracking = true;
                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                        tracking = false;
                    }

                });
                mediaPlayer.seekTo(0);
                binding.seekBar.incrementProgressBy(1);
                binding.seekBar.setMax(mediaPlayer.getDuration());
            }
        });

    }

    protected void doSomeOperations(Intent data) {

        Uri vid = data.getData();
        String videoPath = getRealPathFromURI(vid);
        try {
            mediaPlayer.setDataSource(videoPath);

        } catch (IOException e) {
            e.printStackTrace();
        }


        try {
            mediaPlayer.prepare();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    public String getRealPathFromURI(Uri uri) {
        String path = "";
        if (getActivity().getContentResolver() != null) {
            Cursor cursor = getActivity().getContentResolver().query(uri, null, null, null, null);
            if (cursor != null) {
                cursor.moveToFirst();
                int idx = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
                path = cursor.getString(idx);
                cursor.close();
            }
        }
        return path;
    }

    @Override
    public void onSurfaceTextureSizeChanged(@NonNull SurfaceTexture surfaceTexture, int i,
                                            int i1) {

    }

    @Override
    public boolean onSurfaceTextureDestroyed(@NonNull SurfaceTexture surfaceTexture) {
        return false;
    }

    @Override
    public void onSurfaceTextureUpdated(@NonNull SurfaceTexture surfaceTexture) {

    }


    /**
     * Checks if the app has permission to write to device storage
     * <p>
     * If the app does not has permission then the user will be prompted to grant permissions
     *
     * @param activity
     */
    public static void verifyStoragePermissions(Activity activity) {
        // Check if we have write permission
        int permission = ActivityCompat.checkSelfPermission(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE);

        if (permission != PackageManager.PERMISSION_GRANTED) {
            // We don't have permission so prompt the user
            ActivityCompat.requestPermissions(
                    activity,
                    PERMISSIONS_STORAGE,
                    REQUEST_EXTERNAL_STORAGE
            );
        }
    }
}